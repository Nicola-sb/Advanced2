package ClassesExercise.FirstTask.OpinionPoll;

import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //Create Person class with two fields String name and int age.
        // Write a program that reads from the console N lines of personal information
        // and then prints all people whose age is more than 30 years, sorted in alphabetical order.

        Map<String,Integer>mapPerson=new TreeMap<>();
        int n=Integer.parseInt(scanner.nextLine());
        for(int i=1 ;i<=n ;i++){
            String []personData=scanner.nextLine().split(" ");
            String personName=personData[0];
            int age=Integer.parseInt(personData[1]);

            Person person=new Person(personName,age);
            if(age > 30){
                mapPerson.put(personName,age);
            }
        }

        mapPerson.entrySet().forEach(entry -> System.out.println(entry.getKey()+" - "+entry.getValue()));
    }
}
