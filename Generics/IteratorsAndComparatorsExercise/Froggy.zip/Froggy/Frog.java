package IteratorsAndComparatorsExercise.Froggy;

import java.util.Iterator;
import java.util.List;

public class Frog implements Iterator<Frog> {




    @Override
    public boolean hasNext() {
        return false;
    }

    @Override
    public Frog next() {
        return null;
    }
    //, create a Class - Frog and implement the interface Iterator. Keep in mind, you will be given integers only.
}
